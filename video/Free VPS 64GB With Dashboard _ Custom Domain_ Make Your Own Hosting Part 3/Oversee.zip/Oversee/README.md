# Oversee Dashboard

![Oversee Logo](https://raw.githubusercontent.com/hydren-dev/Oversee/refs/heads/main/oversee.webp)

Oversee is a sleek and efficient dashboard designed for managing your resources with ease. While Discord login isn’t implemented yet, you can still enjoy a seamless experience managing your system.

### Installation

To install and start the Oversee dashboard, run the following commands:

```bash
git clone https://github.com/hydren-dev/Oversee.git && cd Oversee && npm install && npm run seed && npm run createUser && node .
```

### Notes

- Stay tuned for updates as Discord login is in progress.
- Created with ❤️ by **ma4z**.
