node -v

# Replace Startup Variables
echo ":/home/container$ ${START}"

# Run the Server
eval ${START}
